import CRMDashboard from './CRMDashboard'

export default function App() {
  return <CRMDashboard />
}
