import { useState, useEffect, useRef } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid, Legend, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Treemap } from "recharts";

// ─── DATA ────────────────────────────────────────────────────────────────────
const CRM_DATA = [
  { name: "Lithium", symbol: "Li", category: "Battery", china: 68, chile: 11, australia: 15, eu: 1, greece: 0, price: 12800, priceChange: -18.2, risk: 92, demand2030: 280, unit: "$/t" },
  { name: "Cobalt", symbol: "Co", category: "Battery", china: 3, drc: 74, russia: 4, eu: 0, greece: 0, price: 29500, priceChange: -5.1, risk: 88, demand2030: 195, unit: "$/t" },
  { name: "Rare Earths", symbol: "REE", category: "Magnets", china: 70, myanmar: 12, usa: 8, eu: 0, greece: 0.1, price: 78000, priceChange: 24.6, risk: 97, demand2030: 310, unit: "$/t" },
  { name: "Gallium", symbol: "Ga", category: "Semiconductors", china: 94, japan: 2, korea: 1, eu: 1, greece: 0.5, price: 320, priceChange: 42.3, risk: 98, demand2030: 220, unit: "$/kg" },
  { name: "Germanium", symbol: "Ge", category: "Semiconductors", china: 83, canada: 5, belgium: 4, eu: 4, greece: 0, price: 1850, priceChange: 31.7, risk: 95, demand2030: 175, unit: "$/kg" },
  { name: "Graphite", symbol: "C", category: "Battery", china: 65, mozambique: 8, brazil: 7, eu: 0, greece: 0, price: 1200, priceChange: -8.4, risk: 85, demand2030: 350, unit: "$/t" },
  { name: "Manganese", symbol: "Mn", category: "Steel", china: 30, southAfrica: 28, gabon: 17, eu: 0, greece: 0, price: 4.2, priceChange: 12.1, risk: 72, demand2030: 160, unit: "$/kg" },
  { name: "Titanium", symbol: "Ti", category: "Aerospace", china: 57, japan: 18, russia: 10, eu: 3, greece: 0, price: 12500, priceChange: 8.3, risk: 78, demand2030: 155, unit: "$/t" },
  { name: "Tungsten", symbol: "W", category: "Industrial", china: 82, vietnam: 5, russia: 4, eu: 2, greece: 0, price: 35000, priceChange: 15.4, risk: 91, demand2030: 140, unit: "$/t" },
  { name: "Bauxite", symbol: "Al₂O₃", category: "Metals", china: 23, australia: 28, guinea: 22, eu: 5, greece: 2.8, price: 52, priceChange: 3.2, risk: 55, demand2030: 130, unit: "$/t" },
  { name: "Nickel", symbol: "Ni", category: "Battery", indonesia: 49, philippines: 10, russia: 6, eu: 3, greece: 1.2, price: 16200, priceChange: -12.5, risk: 68, demand2030: 240, unit: "$/t" },
  { name: "Antimony", symbol: "Sb", category: "Industrial", china: 55, tajikistan: 15, russia: 7, eu: 0, greece: 0.2, price: 25000, priceChange: 102.5, risk: 93, demand2030: 145, unit: "$/t" },
  { name: "Magnesite", symbol: "MgCO₃", category: "Refractories", china: 68, turkey: 10, brazil: 5, eu: 4, greece: 3.5, price: 120, priceChange: 5.8, risk: 62, demand2030: 115, unit: "$/t" },
  { name: "Perlite", symbol: "SiO₂", category: "Industrial Minerals", china: 15, greece: 30, turkey: 18, usa: 12, eu: 32, price: 85, priceChange: 2.1, risk: 25, demand2030: 110, unit: "$/t" },
  { name: "Bentonite", symbol: "Mont.", category: "Industrial Minerals", usa: 20, china: 18, greece: 12, india: 10, eu: 18, price: 95, priceChange: 1.5, risk: 30, demand2030: 105, unit: "$/t" },
  { name: "Marble", symbol: "CaCO₃", category: "Dimension Stone", italy: 22, turkey: 18, china: 15, greece: 8, eu: 35, price: 250, priceChange: 4.7, risk: 18, demand2030: 120, unit: "$/t" },
];

const GREECE_MINERALS = CRM_DATA.filter(m => m.greece > 0).sort((a, b) => b.greece - a.greece);

const EU_IMPORT_DEPENDENCY = [
  { material: "REE", dependency: 98, source: "China" },
  { material: "Gallium", dependency: 97, source: "China" },
  { material: "Germanium", dependency: 96, source: "China" },
  { material: "Lithium", dependency: 95, source: "Chile/Australia" },
  { material: "Graphite", dependency: 94, source: "China" },
  { material: "Cobalt", dependency: 86, source: "DRC" },
  { material: "Titanium", dependency: 82, source: "China/Japan" },
  { material: "Tungsten", dependency: 80, source: "China" },
  { material: "Antimony", dependency: 78, source: "China" },
  { material: "Nickel", dependency: 45, source: "Indonesia" },
  { material: "Bauxite", dependency: 38, source: "Guinea" },
  { material: "Magnesite", dependency: 32, source: "China/Turkey" },
];

const PRICE_HISTORY = {
  "Rare Earths": [
    { month: "M06", value: 62000 }, { month: "J07", value: 58000 }, { month: "A08", value: 64000 },
    { month: "S09", value: 67000 }, { month: "O10", value: 71000 }, { month: "N11", value: 68000 },
    { month: "D12", value: 72000 }, { month: "J01", value: 74000 }, { month: "F02", value: 76000 },
    { month: "M03", value: 78000 },
  ],
  "Lithium": [
    { month: "M06", value: 22000 }, { month: "J07", value: 20000 }, { month: "A08", value: 18500 },
    { month: "S09", value: 17200 }, { month: "O10", value: 16000 }, { month: "N11", value: 15100 },
    { month: "D12", value: 14800 }, { month: "J01", value: 14200 }, { month: "F02", value: 13400 },
    { month: "M03", value: 12800 },
  ],
  "Gallium": [
    { month: "M06", value: 210 }, { month: "J07", value: 225 }, { month: "A08", value: 240 },
    { month: "S09", value: 250 }, { month: "O10", value: 265 }, { month: "N11", value: 278 },
    { month: "D12", value: 295 }, { month: "J01", value: 305 }, { month: "F02", value: 312 },
    { month: "M03", value: 320 },
  ],
  "Antimony": [
    { month: "M06", value: 12000 }, { month: "J07", value: 13500 }, { month: "A08", value: 15000 },
    { month: "S09", value: 17500 }, { month: "O10", value: 19000 }, { month: "N11", value: 20500 },
    { month: "D12", value: 22000 }, { month: "J01", value: 23500 }, { month: "F02", value: 24200 },
    { month: "M03", value: 25000 },
  ],
  "Cobalt": [
    { month: "M06", value: 33000 }, { month: "J07", value: 32500 }, { month: "A08", value: 31800 },
    { month: "S09", value: 31200 }, { month: "O10", value: 30800 }, { month: "N11", value: 30500 },
    { month: "D12", value: 30200 }, { month: "J01", value: 29800 }, { month: "F02", value: 29600 },
    { month: "M03", value: 29500 },
  ],
  "Nickel": [
    { month: "M06", value: 21000 }, { month: "J07", value: 20200 }, { month: "A08", value: 19500 },
    { month: "S09", value: 19000 }, { month: "O10", value: 18200 }, { month: "N11", value: 17800 },
    { month: "D12", value: 17200 }, { month: "J01", value: 16800 }, { month: "F02", value: 16500 },
    { month: "M03", value: 16200 },
  ],
};

const CATEGORIES = ["All", "Battery", "Magnets", "Semiconductors", "Steel", "Aerospace", "Industrial", "Metals", "Refractories", "Industrial Minerals", "Dimension Stone"];

const TABS = [
  { id: "overview", label: "Επισκόπηση", labelEn: "Overview" },
  { id: "prices", label: "Τιμές & Τάσεις", labelEn: "Prices" },
  { id: "supply", label: "Εφοδιαστική Αλυσίδα", labelEn: "Supply Chain" },
  { id: "greece", label: "Ελλάδα", labelEn: "Greece" },
];

// ─── THEME ───────────────────────────────────────────────────────────────────
const COLORS = {
  bg: "#0a0e14",
  surface: "#111820",
  surfaceAlt: "#161d27",
  border: "#1e2a38",
  borderLight: "#2a3a4e",
  text: "#c8d6e5",
  textDim: "#6b7f95",
  textBright: "#e8f0f8",
  accent: "#d4a056",
  accentDim: "#8b6a35",
  copper: "#cd7f32",
  gold: "#d4a056",
  rare: "#4ecdc4",
  danger: "#e74c3c",
  success: "#27ae60",
  info: "#3498db",
  chart: ["#d4a056", "#4ecdc4", "#e74c3c", "#3498db", "#9b59b6", "#1abc9c", "#e67e22", "#95a5a6"],
};

// ─── COMPONENTS ──────────────────────────────────────────────────────────────
const RiskBadge = ({ value }) => {
  const color = value >= 90 ? COLORS.danger : value >= 70 ? COLORS.copper : value >= 50 ? COLORS.gold : COLORS.success;
  const label = value >= 90 ? "ΚΡΙΣΙΜΟ" : value >= 70 ? "ΥΨΗΛΟ" : value >= 50 ? "ΜΕΤΡΙΟ" : "ΧΑΜΗΛΟ";
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "2px 8px", borderRadius: 3, fontSize: 10, fontWeight: 700,
      background: `${color}18`, color: color, border: `1px solid ${color}33`,
      letterSpacing: "0.05em", fontFamily: "'JetBrains Mono', monospace",
    }}>
      <span style={{ width: 5, height: 5, borderRadius: "50%", background: color, boxShadow: `0 0 6px ${color}` }} />
      {label}
    </span>
  );
};

const PriceChange = ({ value }) => {
  const positive = value > 0;
  return (
    <span style={{
      color: positive ? COLORS.success : COLORS.danger,
      fontFamily: "'JetBrains Mono', monospace",
      fontSize: 12, fontWeight: 600,
    }}>
      {positive ? "▲" : "▼"} {Math.abs(value).toFixed(1)}%
    </span>
  );
};

const StatCard = ({ label, value, sub, accent = false, icon }) => (
  <div style={{
    background: COLORS.surface, border: `1px solid ${COLORS.border}`,
    borderTop: accent ? `2px solid ${COLORS.accent}` : `1px solid ${COLORS.border}`,
    padding: "16px 18px", borderRadius: 4, flex: 1, minWidth: 160,
  }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
      <div>
        <div style={{ color: COLORS.textDim, fontSize: 10, letterSpacing: "0.08em", fontWeight: 600, textTransform: "uppercase", marginBottom: 6, fontFamily: "'JetBrains Mono', monospace" }}>{label}</div>
        <div style={{ color: accent ? COLORS.accent : COLORS.textBright, fontSize: 26, fontWeight: 800, fontFamily: "'JetBrains Mono', monospace", lineHeight: 1 }}>{value}</div>
      </div>
      {icon && <span style={{ fontSize: 22, opacity: 0.3 }}>{icon}</span>}
    </div>
    {sub && <div style={{ color: COLORS.textDim, fontSize: 11, marginTop: 6 }}>{sub}</div>}
  </div>
);

const MiniSparkline = ({ data, color = COLORS.accent, width = 80, height = 28 }) => {
  if (!data || data.length === 0) return null;
  const values = data.map(d => d.value);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const points = values.map((v, i) =>
    `${(i / (values.length - 1)) * width},${height - ((v - min) / range) * (height - 4) - 2}`
  ).join(" ");
  return (
    <svg width={width} height={height} style={{ display: "block" }}>
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "#0d1117", border: `1px solid ${COLORS.borderLight}`,
      padding: "8px 12px", borderRadius: 4, fontSize: 11,
      boxShadow: "0 8px 24px rgba(0,0,0,0.6)",
    }}>
      <div style={{ color: COLORS.textBright, fontWeight: 700, marginBottom: 4 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color || COLORS.text, display: "flex", gap: 8, alignItems: "center" }}>
          <span style={{ width: 8, height: 8, borderRadius: 2, background: p.color || COLORS.accent, display: "inline-block" }} />
          <span>{p.name}: <strong>{typeof p.value === "number" ? p.value.toLocaleString() : p.value}</strong></span>
        </div>
      ))}
    </div>
  );
};

// ─── MAIN DASHBOARD ──────────────────────────────────────────────────────────
export default function CRMDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedMineral, setSelectedMineral] = useState("Rare Earths");
  const [searchTerm, setSearchTerm] = useState("");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => { setLoaded(true); }, []);

  const filtered = CRM_DATA.filter(m => {
    if (selectedCategory !== "All" && m.category !== selectedCategory) return false;
    if (searchTerm && !m.name.toLowerCase().includes(searchTerm.toLowerCase()) && !m.symbol.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const topRisks = [...CRM_DATA].sort((a, b) => b.risk - a.risk).slice(0, 5);
  const topGainers = [...CRM_DATA].sort((a, b) => b.priceChange - a.priceChange).slice(0, 5);

  const chinaConcentration = CRM_DATA.filter(m => (m.china || 0) >= 50);

  const supplyConcentrationData = CRM_DATA.map(m => {
    const vals = Object.entries(m).filter(([k, v]) => typeof v === "number" && !["price", "priceChange", "risk", "demand2030", "greece", "eu"].includes(k)).sort((a, b) => b[1] - a[1]);
    const top1 = vals[0]?.[1] || 0;
    return { name: m.symbol, hhi: top1, risk: m.risk };
  }).sort((a, b) => b.hhi - a.hhi);

  return (
    <div style={{
      background: COLORS.bg, color: COLORS.text, minHeight: "100vh",
      fontFamily: "'Noto Sans', 'Segoe UI', sans-serif",
      transition: "opacity 0.6s", opacity: loaded ? 1 : 0,
    }}>
      <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700;800&family=Noto+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />

      {/* ─── HEADER ─── */}
      <div style={{
        background: `linear-gradient(180deg, ${COLORS.surfaceAlt} 0%, ${COLORS.bg} 100%)`,
        borderBottom: `1px solid ${COLORS.border}`,
        padding: "20px 28px 0",
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12, marginBottom: 16 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
              <span style={{
                fontFamily: "'JetBrains Mono', monospace", fontSize: 9, fontWeight: 700,
                background: `${COLORS.accent}22`, color: COLORS.accent, padding: "2px 8px",
                borderRadius: 2, border: `1px solid ${COLORS.accent}44`, letterSpacing: "0.1em",
              }}>CRM MONITOR v1.0</span>
              <span style={{
                fontFamily: "'JetBrains Mono', monospace", fontSize: 9, fontWeight: 600,
                color: COLORS.success, letterSpacing: "0.05em",
              }}>● LIVE DATA</span>
            </div>
            <h1 style={{
              fontSize: 22, fontWeight: 800, color: COLORS.textBright, margin: 0, lineHeight: 1.2,
              letterSpacing: "-0.02em",
            }}>
              Κρίσιμες Πρώτες Ύλες — EU Dashboard
            </h1>
            <p style={{ fontSize: 12, color: COLORS.textDim, margin: "4px 0 0", maxWidth: 600 }}>
              Παρακολούθηση κρίσιμων ορυκτών πρώτων υλών · Τιμές · Εφοδιαστική αλυσίδα · Θέση Ελλάδας
            </p>
          </div>
          <div style={{
            fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: COLORS.textDim,
            textAlign: "right", lineHeight: 1.6,
          }}>
            <div style={{ color: COLORS.textBright }}>Μάρτιος 2026</div>
            <div>EU CRM Act 2024</div>
            <div style={{ fontSize: 9 }}>oryktosploutos.net</div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 0 }}>
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
              background: activeTab === tab.id ? COLORS.surface : "transparent",
              color: activeTab === tab.id ? COLORS.accent : COLORS.textDim,
              border: `1px solid ${activeTab === tab.id ? COLORS.border : "transparent"}`,
              borderBottom: activeTab === tab.id ? `1px solid ${COLORS.surface}` : `1px solid ${COLORS.border}`,
              padding: "9px 18px", fontSize: 12, fontWeight: 600, cursor: "pointer",
              borderRadius: "4px 4px 0 0", marginBottom: -1,
              transition: "all 0.15s",
              fontFamily: "'Noto Sans', sans-serif",
            }}>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ─── CONTENT ─── */}
      <div style={{ padding: "20px 28px 40px", maxWidth: 1280, margin: "0 auto" }}>

        {/* ═══ OVERVIEW TAB ═══ */}
        {activeTab === "overview" && (
          <div>
            {/* Stats Row */}
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 20 }}>
              <StatCard label="Κρίσιμες ΟΠΥ (EU List)" value="34" sub="Critical Raw Materials Act 2024" accent icon="⬡" />
              <StatCard label="Υψηλού Ρίσκου" value={CRM_DATA.filter(m => m.risk >= 85).length} sub="Supply concentration ≥85%" icon="⚠" />
              <StatCard label="Κίνα Κυριαρχία" value={`${chinaConcentration.length}`} sub="Υλικά με >50% κινεζικό μερίδιο" icon="◆" />
              <StatCard label="Μεγ. Αύξηση Τιμής" value={`+${topGainers[0]?.priceChange}%`} sub={topGainers[0]?.name} accent icon="▲" />
            </div>

            {/* Main Grid */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 16, marginBottom: 20 }}>

              {/* Material Table */}
              <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, overflow: "hidden" }}>
                <div style={{ padding: "12px 16px", borderBottom: `1px solid ${COLORS.border}`, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: COLORS.textBright }}>Πίνακας Κρίσιμων Πρώτων Υλών</span>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    <input
                      type="text" placeholder="Αναζήτηση..."
                      value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                      style={{
                        background: COLORS.bg, border: `1px solid ${COLORS.border}`, borderRadius: 3,
                        color: COLORS.text, padding: "4px 10px", fontSize: 11, width: 120, outline: "none",
                        fontFamily: "'Noto Sans', sans-serif",
                      }}
                    />
                    <select
                      value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)}
                      style={{
                        background: COLORS.bg, border: `1px solid ${COLORS.border}`, borderRadius: 3,
                        color: COLORS.text, padding: "4px 8px", fontSize: 11, outline: "none", cursor: "pointer",
                      }}
                    >
                      {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
                <div style={{ overflowX: "auto", maxHeight: 420 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                    <thead>
                      <tr style={{ background: COLORS.surfaceAlt }}>
                        {["Υλικό", "Κατηγ.", "Τιμή", "Μεταβολή", "Τάση", "Ρίσκο", "Ζήτηση 2030"].map(h => (
                          <th key={h} style={{
                            padding: "8px 12px", textAlign: "left", fontWeight: 700,
                            color: COLORS.textDim, fontSize: 10, letterSpacing: "0.06em",
                            textTransform: "uppercase", borderBottom: `1px solid ${COLORS.border}`,
                            fontFamily: "'JetBrains Mono', monospace", whiteSpace: "nowrap",
                          }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((m, i) => (
                        <tr key={m.name}
                          onClick={() => { setSelectedMineral(m.name); setActiveTab("prices"); }}
                          style={{
                            cursor: "pointer", borderBottom: `1px solid ${COLORS.border}08`,
                            transition: "background 0.1s",
                          }}
                          onMouseEnter={e => e.currentTarget.style.background = COLORS.surfaceAlt}
                          onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                        >
                          <td style={{ padding: "8px 12px", fontWeight: 600, color: COLORS.textBright }}>
                            <span style={{ color: COLORS.accent, fontFamily: "'JetBrains Mono', monospace", fontSize: 10, marginRight: 6 }}>{m.symbol}</span>
                            {m.name}
                          </td>
                          <td style={{ padding: "8px 12px", color: COLORS.textDim, fontSize: 11 }}>{m.category}</td>
                          <td style={{ padding: "8px 12px", fontFamily: "'JetBrains Mono', monospace", color: COLORS.textBright, fontWeight: 600 }}>
                            {m.price.toLocaleString()} <span style={{ fontSize: 9, color: COLORS.textDim }}>{m.unit}</span>
                          </td>
                          <td style={{ padding: "8px 12px" }}><PriceChange value={m.priceChange} /></td>
                          <td style={{ padding: "8px 12px" }}>
                            <MiniSparkline
                              data={PRICE_HISTORY[m.name]}
                              color={m.priceChange >= 0 ? COLORS.success : COLORS.danger}
                            />
                          </td>
                          <td style={{ padding: "8px 12px" }}><RiskBadge value={m.risk} /></td>
                          <td style={{ padding: "8px 12px" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <div style={{ flex: 1, background: `${COLORS.border}`, borderRadius: 2, height: 4, maxWidth: 80 }}>
                                <div style={{
                                  width: `${Math.min(m.demand2030 / 3.5, 100)}%`, height: "100%",
                                  background: m.demand2030 > 250 ? COLORS.danger : m.demand2030 > 150 ? COLORS.accent : COLORS.info,
                                  borderRadius: 2,
                                }} />
                              </div>
                              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: COLORS.textDim }}>{m.demand2030}%</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Side Panels */}
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {/* Top Risks */}
                <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: 16 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: COLORS.danger, letterSpacing: "0.06em", marginBottom: 12, fontFamily: "'JetBrains Mono', monospace", textTransform: "uppercase" }}>
                    ⚠ Υψηλότερο Ρίσκο Εφοδιασμού
                  </div>
                  {topRisks.map(m => (
                    <div key={m.name} style={{
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                      padding: "6px 0", borderBottom: `1px solid ${COLORS.border}08`,
                    }}>
                      <div>
                        <span style={{ color: COLORS.textBright, fontSize: 12, fontWeight: 600 }}>{m.name}</span>
                        <span style={{ color: COLORS.textDim, fontSize: 10, marginLeft: 6 }}>{m.category}</span>
                      </div>
                      <div style={{
                        fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 800,
                        color: m.risk >= 95 ? COLORS.danger : COLORS.copper,
                      }}>{m.risk}</div>
                    </div>
                  ))}
                </div>

                {/* Top Price Movers */}
                <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: 16 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: COLORS.accent, letterSpacing: "0.06em", marginBottom: 12, fontFamily: "'JetBrains Mono', monospace", textTransform: "uppercase" }}>
                    ▲ Μεγαλύτερες Αυξήσεις Τιμών
                  </div>
                  {topGainers.map(m => (
                    <div key={m.name} style={{
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                      padding: "6px 0", borderBottom: `1px solid ${COLORS.border}08`,
                    }}>
                      <span style={{ color: COLORS.textBright, fontSize: 12, fontWeight: 600 }}>{m.name}</span>
                      <PriceChange value={m.priceChange} />
                    </div>
                  ))}
                </div>

                {/* Demand Outlook */}
                <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: 16 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: COLORS.rare, letterSpacing: "0.06em", marginBottom: 12, fontFamily: "'JetBrains Mono', monospace", textTransform: "uppercase" }}>
                    ◆ Πρόβλεψη Ζήτησης 2030
                  </div>
                  <div style={{ fontSize: 11, color: COLORS.textDim, lineHeight: 1.6 }}>
                    Η ζήτηση για κρίσιμα ορυκτά αναμένεται να αυξηθεί δραματικά ως το 2030, κυρίως λόγω ηλεκτροκίνησης, ΑΠΕ και ψηφιακού μετασχηματισμού. Το Graphite (+350%) και οι REE (+310%) εμφανίζουν τη μεγαλύτερη προβλεπόμενη αύξηση.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ═══ PRICES TAB ═══ */}
        {activeTab === "prices" && (
          <div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
              {Object.keys(PRICE_HISTORY).map(name => (
                <button key={name} onClick={() => setSelectedMineral(name)} style={{
                  background: selectedMineral === name ? `${COLORS.accent}22` : COLORS.surface,
                  color: selectedMineral === name ? COLORS.accent : COLORS.textDim,
                  border: `1px solid ${selectedMineral === name ? COLORS.accent + "44" : COLORS.border}`,
                  padding: "6px 14px", borderRadius: 3, fontSize: 12, fontWeight: 600, cursor: "pointer",
                  transition: "all 0.15s",
                }}>
                  {name}
                </button>
              ))}
            </div>

            {/* Price Chart */}
            <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px 20px 12px", marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <div>
                  <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: COLORS.textBright }}>{selectedMineral}</h3>
                  <span style={{ fontSize: 11, color: COLORS.textDim }}>Εξέλιξη τιμής 10 μηνών · {CRM_DATA.find(m => m.name === selectedMineral)?.unit || ""}</span>
                </div>
                {(() => {
                  const m = CRM_DATA.find(m => m.name === selectedMineral);
                  return m ? (
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 24, fontWeight: 800, color: COLORS.textBright }}>
                        {m.price.toLocaleString()}
                      </div>
                      <PriceChange value={m.priceChange} />
                    </div>
                  ) : null;
                })()}
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={PRICE_HISTORY[selectedMineral] || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
                  <XAxis dataKey="month" tick={{ fill: COLORS.textDim, fontSize: 10 }} stroke={COLORS.border} />
                  <YAxis tick={{ fill: COLORS.textDim, fontSize: 10 }} stroke={COLORS.border} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="value" stroke={COLORS.accent} strokeWidth={2.5} dot={{ fill: COLORS.accent, r: 3 }} activeDot={{ r: 5, fill: COLORS.accent }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Price Comparison */}
            <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px 20px 12px" }}>
              <h3 style={{ margin: "0 0 4px", fontSize: 14, fontWeight: 700, color: COLORS.textBright }}>Μεταβολή Τιμών — Ετήσια Σύγκριση</h3>
              <p style={{ margin: "0 0 16px", fontSize: 11, color: COLORS.textDim }}>Ποσοστιαία μεταβολή τιμών τελευταίους 12 μήνες</p>
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={[...CRM_DATA].sort((a, b) => b.priceChange - a.priceChange)} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} horizontal={false} />
                  <XAxis type="number" tick={{ fill: COLORS.textDim, fontSize: 10 }} stroke={COLORS.border} />
                  <YAxis type="category" dataKey="name" tick={{ fill: COLORS.text, fontSize: 11 }} width={100} stroke={COLORS.border} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="priceChange" name="Μεταβολή %" radius={[0, 3, 3, 0]}>
                    {[...CRM_DATA].sort((a, b) => b.priceChange - a.priceChange).map((entry, i) => (
                      <Cell key={i} fill={entry.priceChange >= 0 ? COLORS.success : COLORS.danger} fillOpacity={0.8} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* ═══ SUPPLY CHAIN TAB ═══ */}
        {activeTab === "supply" && (
          <div>
            {/* EU Import Dependency */}
            <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px", marginBottom: 16 }}>
              <h3 style={{ margin: "0 0 4px", fontSize: 14, fontWeight: 700, color: COLORS.textBright }}>Εξάρτηση ΕΕ από Εισαγωγές (%)</h3>
              <p style={{ margin: "0 0 16px", fontSize: 11, color: COLORS.textDim }}>Ποσοστό εξάρτησης της Ευρωπαϊκής Ένωσης από τρίτες χώρες ανά κρίσιμη πρώτη ύλη</p>
              <ResponsiveContainer width="100%" height={340}>
                <BarChart data={EU_IMPORT_DEPENDENCY} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} horizontal={false} />
                  <XAxis type="number" domain={[0, 100]} tick={{ fill: COLORS.textDim, fontSize: 10 }} stroke={COLORS.border} />
                  <YAxis type="category" dataKey="material" tick={{ fill: COLORS.text, fontSize: 11 }} width={90} stroke={COLORS.border} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="dependency" name="Εξάρτηση %" radius={[0, 3, 3, 0]}>
                    {EU_IMPORT_DEPENDENCY.map((entry, i) => (
                      <Cell key={i} fill={entry.dependency >= 90 ? COLORS.danger : entry.dependency >= 70 ? COLORS.copper : entry.dependency >= 50 ? COLORS.accent : COLORS.success} fillOpacity={0.85} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
              {/* China Dominance */}
              <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px" }}>
                <h3 style={{ margin: "0 0 4px", fontSize: 14, fontWeight: 700, color: COLORS.danger }}>Κινεζική Κυριαρχία</h3>
                <p style={{ margin: "0 0 16px", fontSize: 11, color: COLORS.textDim }}>Υλικά με μερίδιο Κίνας &gt;50% στην παγκόσμια παραγωγή</p>
                {chinaConcentration.sort((a, b) => (b.china || 0) - (a.china || 0)).map(m => (
                  <div key={m.name} style={{ marginBottom: 10 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 3 }}>
                      <span style={{ color: COLORS.textBright, fontWeight: 600 }}>{m.name}</span>
                      <span style={{ fontFamily: "'JetBrains Mono', monospace", color: COLORS.danger, fontWeight: 700 }}>{m.china}%</span>
                    </div>
                    <div style={{ background: COLORS.bg, borderRadius: 2, height: 6 }}>
                      <div style={{
                        width: `${m.china}%`, height: "100%",
                        background: `linear-gradient(90deg, ${COLORS.danger}88, ${COLORS.danger})`,
                        borderRadius: 2, transition: "width 0.8s ease",
                      }} />
                    </div>
                  </div>
                ))}
              </div>

              {/* Supply Concentration Index */}
              <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px" }}>
                <h3 style={{ margin: "0 0 4px", fontSize: 14, fontWeight: 700, color: COLORS.accent }}>Δείκτης Συγκέντρωσης Εφοδιασμού</h3>
                <p style={{ margin: "0 0 16px", fontSize: 11, color: COLORS.textDim }}>Μερίδιο κορυφαίου παραγωγού (%) — μέτρο μονοπωλιακού κινδύνου</p>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={supplyConcentrationData}>
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
                    <XAxis dataKey="name" tick={{ fill: COLORS.textDim, fontSize: 9 }} stroke={COLORS.border} />
                    <YAxis tick={{ fill: COLORS.textDim, fontSize: 10 }} stroke={COLORS.border} domain={[0, 100]} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="hhi" name="Μερίδιο Top-1 %" radius={[3, 3, 0, 0]}>
                      {supplyConcentrationData.map((entry, i) => (
                        <Cell key={i} fill={entry.hhi >= 80 ? COLORS.danger : entry.hhi >= 50 ? COLORS.accent : COLORS.success} fillOpacity={0.8} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* CRM Act Key Targets */}
            <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px" }}>
              <h3 style={{ margin: "0 0 12px", fontSize: 14, fontWeight: 700, color: COLORS.rare }}>Στόχοι EU Critical Raw Materials Act 2024</h3>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
                {[
                  { target: "10%", label: "Εξόρυξη εντός ΕΕ", desc: "Τουλάχιστον 10% της ετήσιας κατανάλωσης να εξορύσσεται εντός ΕΕ", color: COLORS.accent },
                  { target: "40%", label: "Μεταποίηση εντός ΕΕ", desc: "40% της ετήσιας κατανάλωσης να μεταποιείται εντός ΕΕ", color: COLORS.rare },
                  { target: "25%", label: "Ανακύκλωση εντός ΕΕ", desc: "25% τουλάχιστον από δευτερογενείς πρώτες ύλες (ανακύκλωση)", color: COLORS.success },
                  { target: "<65%", label: "Όριο Εξάρτησης", desc: "Μέγιστο 65% εισαγωγών από μία τρίτη χώρα ανά στρατηγικό υλικό", color: COLORS.danger },
                ].map((item, i) => (
                  <div key={i} style={{ background: COLORS.bg, border: `1px solid ${COLORS.border}`, borderLeft: `3px solid ${item.color}`, borderRadius: 4, padding: "14px 16px" }}>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 28, fontWeight: 800, color: item.color, marginBottom: 4 }}>{item.target}</div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.textBright, marginBottom: 4 }}>{item.label}</div>
                    <div style={{ fontSize: 11, color: COLORS.textDim, lineHeight: 1.5 }}>{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ═══ GREECE TAB ═══ */}
        {activeTab === "greece" && (
          <div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 20 }}>
              <StatCard label="Ελληνικά ΟΠΥ" value={GREECE_MINERALS.length} sub="Ορυκτά με ελληνική παραγωγή" accent icon="⚒" />
              <StatCard label="Κορυφαίο Εξαγωγικό" value="Περλίτης" sub="30% παγκόσμιας παραγωγής" icon="◆" />
              <StatCard label="Ελληνικό Μάρμαρο" value="8%" sub="Παγκόσμιο μερίδιο" icon="▣" />
              <StatCard label="Βωξίτης / Αλουμίνιο" value="2.8%" sub="Ευρωπαϊκή σημασία" icon="⬡" />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
              {/* Greece's Mineral Production */}
              <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px" }}>
                <h3 style={{ margin: "0 0 4px", fontSize: 14, fontWeight: 700, color: COLORS.accent }}>Ελληνική Παραγωγή — Παγκόσμιο Μερίδιο (%)</h3>
                <p style={{ margin: "0 0 16px", fontSize: 11, color: COLORS.textDim }}>Ποσοστό συμμετοχής της Ελλάδας στην παγκόσμια παραγωγή κρίσιμων & βιομηχανικών ορυκτών</p>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={GREECE_MINERALS} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} horizontal={false} />
                    <XAxis type="number" tick={{ fill: COLORS.textDim, fontSize: 10 }} stroke={COLORS.border} />
                    <YAxis type="category" dataKey="name" tick={{ fill: COLORS.text, fontSize: 11 }} width={90} stroke={COLORS.border} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="greece" name="Ελλάδα %" radius={[0, 3, 3, 0]}>
                      {GREECE_MINERALS.map((entry, i) => (
                        <Cell key={i} fill={COLORS.chart[i % COLORS.chart.length]} fillOpacity={0.85} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Greece vs EU */}
              <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px" }}>
                <h3 style={{ margin: "0 0 4px", fontSize: 14, fontWeight: 700, color: COLORS.rare }}>Ελλάδα vs ΕΕ — Παραγωγικό Μερίδιο (%)</h3>
                <p style={{ margin: "0 0 16px", fontSize: 11, color: COLORS.textDim }}>Σύγκριση ελληνικής παραγωγής με σύνολο ΕΕ</p>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={GREECE_MINERALS}>
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
                    <XAxis dataKey="symbol" tick={{ fill: COLORS.textDim, fontSize: 10 }} stroke={COLORS.border} />
                    <YAxis tick={{ fill: COLORS.textDim, fontSize: 10 }} stroke={COLORS.border} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="greece" name="Ελλάδα %" fill={COLORS.accent} radius={[3, 3, 0, 0]} />
                    <Bar dataKey="eu" name="ΕΕ σύνολο %" fill={COLORS.rare} radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Strategic Analysis */}
            <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 4, padding: "20px" }}>
              <h3 style={{ margin: "0 0 12px", fontSize: 14, fontWeight: 700, color: COLORS.textBright }}>Στρατηγική Θέση Ελλάδας στην Ευρωπαϊκή Εφοδιαστική Αλυσίδα</h3>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16 }}>
                {[
                  {
                    title: "Περλίτης & Μπεντονίτης",
                    color: COLORS.accent,
                    items: [
                      "Παγκόσμιος ηγέτης στον περλίτη (30% παγκοσμίως)",
                      "Κορυφαία θέση στην ΕΕ στον μπεντονίτη (Μήλος)",
                      "Στρατηγικά βιομηχανικά ορυκτά για πράσινη μετάβαση",
                    ]
                  },
                  {
                    title: "Βωξίτης & Αλουμίνιο",
                    color: COLORS.info,
                    items: [
                      "Metlen: ολοκληρωμένη αλυσίδα αξίας",
                      "Σημαντικά κοιτάσματα Στ. Ελλάδας & Πελοποννήσου",
                      "Ευρωπαϊκή σημασία υπό το CRM Act",
                    ]
                  },
                  {
                    title: "Γάλλιο & Σπάνιες Γαίες",
                    color: COLORS.rare,
                    items: [
                      "Δυνατότητα παραγωγής γαλλίου ως παραπροϊόν βωξίτη",
                      "Ερευνητικά προγράμματα ΕΑΓΜΕ για REE στη Β. Ελλάδα",
                      "Στρατηγική ευκαιρία υπό τον Κανονισμό ΕΕ",
                    ]
                  },
                  {
                    title: "Χρυσός & Μεταλλεύματα",
                    color: COLORS.gold,
                    items: [
                      "Σκουριές (Eldorado/Ελληνικός Χρυσός): μεγάλη ευρωπαϊκή επένδυση",
                      "Κοιτάσματα Cu-Au-Ag στη Θράκη & Χαλκιδική",
                      "Αντιμόνιο: ιστορικά κοιτάσματα Χίου",
                    ]
                  },
                ].map((section, i) => (
                  <div key={i} style={{
                    background: COLORS.bg, border: `1px solid ${COLORS.border}`,
                    borderTop: `2px solid ${section.color}`, borderRadius: 4, padding: 16,
                  }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: section.color, marginBottom: 10 }}>{section.title}</div>
                    {section.items.map((item, j) => (
                      <div key={j} style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 6 }}>
                        <span style={{ color: section.color, fontSize: 8, marginTop: 4 }}>●</span>
                        <span style={{ fontSize: 11, color: COLORS.text, lineHeight: 1.5 }}>{item}</span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ─── FOOTER ─── */}
        <div style={{
          marginTop: 32, paddingTop: 16, borderTop: `1px solid ${COLORS.border}`,
          display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8,
        }}>
          <div style={{ fontSize: 10, color: COLORS.textDim, fontFamily: "'JetBrains Mono', monospace" }}>
            Πηγές: European Commission (CRM Act 2024) · USGS · BGS · ΕΑΓΜΕ · Mineral Commodity Summaries
          </div>
          <div style={{ fontSize: 10, color: COLORS.textDim }}>
            <span style={{ color: COLORS.accent }}>oryktosploutos.net</span> · Ελληνικός Ορυκτός Πλούτος · Μάρτιος 2026
          </div>
        </div>
      </div>
    </div>
  );
}
